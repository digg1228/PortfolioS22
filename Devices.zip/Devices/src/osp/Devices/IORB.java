package osp.Devices;
import osp.IFLModules.*;
import osp.FileSys.OpenFile;
import osp.Threads.ThreadCB;
import osp.Memory.PageTableEntry;

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files


/** 
   This class contains all the information necessary to carry out
   an I/O request.

    @OSPProject Devices
*/

public class IORB extends IflIORB implements SortedItemInterface
{
    /**
       The IORB constructor.
       Must have
       
	   super(thread,page,blockNumber,deviceID,ioType,openFile);

       as its first statement.

       @OSPProject Devices
    */
	
    public IORB(ThreadCB thread, PageTableEntry page, 
		int blockNumber, int deviceID, 
		int ioType, OpenFile openFile) {
        // your code goes here
    	
    	super(thread,page,blockNumber,deviceID,ioType,openFile);
    	
    /*
       Feel free to add methods/fields to improve the readability of your code
    */
    }
    
    public String getKey() {
    	return "Cylinder(" + getCylinder() + ")";
    }
    

    public String toString()
    {
        return "IORB[Id(" + getID() + "),Thread(" + getThread() + "),Device(" + getDeviceID() + "),Diskblock(" + getBlockNumber() + "),Cylinder(" + getCylinder() + ")] ";
    }

    


}

/*
      Feel free to add local classes to improve the readability of your code
*/
